# Storytelling 

## Instructions

* Use the visualizations created for one of the "Student Do" or "Everyone Do" activities from either class to create a story.

* Make sure that each story and text box you add to the chart clearly describes and summarizes the visualization. 

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.